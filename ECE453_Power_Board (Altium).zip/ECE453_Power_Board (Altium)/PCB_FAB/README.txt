The board outline is defined by a 10mil trace found on all gerbers

The board dimensions are 1.771 (45mm) inch x 2.952 inch (75mm)