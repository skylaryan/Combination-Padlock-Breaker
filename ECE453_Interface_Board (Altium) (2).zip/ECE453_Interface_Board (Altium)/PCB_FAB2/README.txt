This board is 100mm x 100mm
the top copper layer is the GTL in the gerber file
